let arrowLeft = document.getElementById("arrow-left");
let arrowRight = document.getElementById("arrow-right");
let multiImages = document.getElementById("multi-images");
let images = document.getElementById('multi-images').getElementsByClassName('carousel_img');
let box = document.getElementById("box");
let currentIndex = 0;
let preIndex = 0;
let timer = null;
let containerWidth = document.body.clientWidth;

document.getElementById('multi-images').style.width = (images.length + 1) * containerWidth + "px";
for(let i=0;i<images.length;i++){
  images[i].style.width = containerWidth + "px";
}
arrowLeft.addEventListener("click", preMove);
arrowRight.addEventListener("click", nextMove);
timer = setInterval(nextMove, 5000);
box.addEventListener("mouseover", function () {
  clearInterval(timer);
  arrowLeft.style.display = "block";
  arrowRight.style.display = "block";
});
box.addEventListener("mouseout", function () {
  timer = setInterval(nextMove, 5000);
  arrowLeft.style.display = "none";
  arrowRight.style.display = "none";
});

function preMove() {
  preIndex = currentIndex;
  if (currentIndex != 0) {
    currentIndex--;
  } else {
    currentIndex = 2;
  }
  moveImage();
}

function nextMove() {
  preIndex = currentIndex;
  if (currentIndex != 2) {
    currentIndex++;
  } else {
    currentIndex = 0;
  }
  moveImage();
}

function moveImage() {
  multiImages.style.transform = "translateX(" + -currentIndex * containerWidth + "px)";
}